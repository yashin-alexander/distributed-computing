#include "ipc.h"

int inc_lamport();
int set_lamport(int val);
timestamp_t get_lamport_time();

